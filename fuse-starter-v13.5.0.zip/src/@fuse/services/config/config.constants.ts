import { InjectionToken } from '@angular/core';

export const FUSE_APP_CONFIG = new InjectionToken<any>('FUSE_APP_CONFIG');
